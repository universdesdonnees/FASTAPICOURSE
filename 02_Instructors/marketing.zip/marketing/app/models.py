from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, JSON
from sqlalchemy.orm import relationship
from app.database import Base

class Client(Base):
    __tablename__ = "clients"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    email = Column(String, unique=True, index=True)
    campaigns = relationship("Campaign", back_populates="client")

class Campaign(Base):
    __tablename__ = "campaigns"
    id = Column(Integer, primary_key=True, index=True)
    campaign_name = Column(String, index=True)
    description = Column(String)
    start_date = Column(DateTime)
    budget = Column(Integer)
    performance_metrics = Column(JSON)
    canal = Column(String)  # Store as a string
    client_id = Column(Integer, ForeignKey('clients.id'))
    client = relationship("Client", back_populates="campaigns")
