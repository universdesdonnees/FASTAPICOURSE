# src/app/generate_fake_data.py

from faker import Faker
from sqlalchemy.orm import Session
from datetime import datetime
from random import randint, choice
from app.database import SessionLocal
from app.models import Client, Campaign

fake = Faker()

def generate_fake_data():
    db: Session = SessionLocal()

    # Generate 10 clients
    for _ in range(10):
        client_name = fake.company()
        client_email = fake.company_email()
        db_client = Client(name=client_name, email=client_email)
        db.add(db_client)
        db.commit()
        db.refresh(db_client)

        # Generate 2 campaigns for each client
        for _ in range(2):
            campaign_name = fake.catch_phrase()
            campaign_description = fake.text(max_nb_chars=200)
            start_date = fake.date_time_this_year(before_now=True, after_now=False)
            budget = randint(10000, 100000)
            performance_metrics = {
                "impressions": randint(1000, 10000),
                "clicks": randint(100, 1000),
                "conversions": randint(10, 100)
            }
            canal = choice(['internet', 'tv', 'radio'])

            db_campaign = Campaign(
                campaign_name=campaign_name,
                description=campaign_description,
                start_date=start_date,
                budget=budget,
                performance_metrics=[performance_metrics],
                canal=canal,  # Store as a string
                client_id=db_client.id
            )
            db.add(db_campaign)

    db.commit()
    db.close()

if __name__ == "__main__":
    generate_fake_data()
