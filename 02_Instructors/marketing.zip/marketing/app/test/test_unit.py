import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlmodel import SQLModel, Session
from sqlmodel.pool import StaticPool

# Import your app and models
from app.main import app
from app.database import get_db, engine, Base  # Import your Base
from app.models import Client, Campaign  # Ensure both models are imported

# Create an in-memory SQLite database for testing
test_engine = create_engine(
    "sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=test_engine)

# Create the database tables
Base.metadata.create_all(bind=test_engine)

@pytest.fixture(name="session")
def session_fixture():
    # Create a fresh database session for each test
    Base.metadata.create_all(bind=test_engine)
    with Session(test_engine) as session:
        yield session
    Base.metadata.drop_all(bind=test_engine)  # Optional: Clean up after tests


@pytest.fixture(name="client")
def client_fixture(session: Session):
    def get_session_override():
        return session

    app.dependency_overrides[get_db] = get_session_override
    client = TestClient(app)
    yield client
    app.dependency_overrides.clear()


def test_create_client(client: TestClient):
    response = client.post(
        "/clients/", json={"name": "Test Client", "email": "test1@example.com"}  # Use a unique email
    )
    data = response.json()

    assert response.status_code == 200
    assert data["name"] == "Test Client"
    assert data["email"] == "test1@example.com"
    assert data["id"] is not None

def test_read_clients(client: TestClient, session: Session):
    client_1 = Client(name="Client One", email="one@example.com")
    client_2 = Client(name="Client Two", email="two@example.com")
    session.add(client_1)
    session.add(client_2)
    session.commit()

    response = client.get("/clients/")
    data = response.json()

    assert response.status_code == 200
    assert len(data) == 2  # Ensure this matches the number of clients added
    assert data[0]["name"] == client_1.name
    assert data[1]["name"] == client_2.name

def test_read_client(client: TestClient, session: Session):
    client_1 = Client(name="Client One", email="one@example.com")
    session.add(client_1)
    session.commit()

    response = client.get(f"/clients/{client_1.id}")
    data = response.json()

    assert response.status_code == 200
    assert data["name"] == client_1.name
    assert data["email"] == client_1.email

def test_update_client(client: TestClient, session: Session):
    client_1 = Client(name="Client One", email="one@example.com")
    session.add(client_1)
    session.commit()

    response = client.put(f"/clients/{client_1.id}", json={"name": "Updated Client", "email": "updated@example.com"})
    data = response.json()

    assert response.status_code == 200
    assert data["name"] == "Updated Client"
    assert data["email"] == "updated@example.com"

def test_delete_client(client: TestClient, session: Session):
    client_1 = Client(name="Client One", email="one@example.com")
    session.add(client_1)
    session.commit()

    response = client.delete(f"/clients/{client_1.id}")

    assert response.status_code == 200
    assert session.get(Client, client_1.id) is None
