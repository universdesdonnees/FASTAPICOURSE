from fastapi import FastAPI
from contextlib import asynccontextmanager
from app.client_routes import router as client_router
from app.campaign_routes import router as campaign_router
from app.database import engine
from app.models import Base
from app.generate_fake_data import generate_fake_data



# Create all tables in the database
Base.metadata.create_all(bind=engine)

version = 'v1'

app = FastAPI(
    title="Marketing Agency API!🚀",
    description="A REST API for a Marketing Agency web service",
    version=version
)

# Define lifespan for FastAPI (startup and shutdown logic)
@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup logic
    print("Generating fake data during startup...")  
    generate_fake_data()  # Ensure this runs during startup
    yield  # Pass control to the rest of the app
    # Shutdown logic can go here if needed (after yield)

# Use the custom lifespan in the FastAPI app
app = FastAPI(lifespan=lifespan)

# Simple root endpoint
@app.get("/")
async def read_root():
    return {"message": "Welcome to the Marketing Agency API! 🚀"}


# Include client and campaign routers
app.include_router(client_router, prefix="/clients", tags=["clients"])
app.include_router(campaign_router, prefix="/campaigns", tags=["campaigns"])
