from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app import models
from app import schemas
from app.database import get_db


router = APIRouter(tags=["clients"])

@router.post("/", response_model=schemas.Client, summary="Create a new client", description="Add a new client to the database with a unique name and email.")
async def create_client(client: schemas.Client, db: Session = Depends(get_db)):
    db_client = models.Client(name=client.name, email=client.email)
    db.add(db_client)
    db.commit()
    db.refresh(db_client)
    return db_client

@router.get("/", response_model=List[schemas.Client], summary="Retrieve all clients", description="Get a list of all clients, with optional pagination.")
async def read_clients(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    clients = db.query(models.Client).offset(skip).limit(limit).all()
    return clients

@router.get("/{client_id}", response_model=schemas.Client, summary="Retrieve a client by ID", description="Get details of a specific client by their ID.")
async def read_client(client_id: int, db: Session = Depends(get_db)):
    try:
        client = db.query(models.Client).filter(models.Client.id == client_id).one()
        return client
    except Exception:
        raise HTTPException(status_code=404, detail="Client not found")

@router.put("/{client_id}", response_model=schemas.Client, summary="Update a client", description="Update the details of an existing client by their ID.")
async def update_client(client_id: int, client: schemas.Client, db: Session = Depends(get_db)):
    try:
        db_client = db.query(models.Client).filter(models.Client.id == client_id).one()
        db_client.name = client.name
        db_client.email = client.email
        db.commit()
        db.refresh(db_client)
        return db_client
    except Exception:
        raise HTTPException(status_code=404, detail="Client not found")

@router.delete("/{client_id}", response_model=schemas.Client, summary="Delete a client", description="Remove a client from the database by their ID.")
async def delete_client(client_id: int, db: Session = Depends(get_db)):
    try:
        db_client = db.query(models.Client).filter(models.Client.id == client_id).one()
        db.delete(db_client)
        db.commit()
        return db_client
    except Exception:
        raise HTTPException(status_code=404, detail="Client not found")
