from pydantic import BaseModel
from datetime import datetime
from typing import List, Dict, Literal

class Client(BaseModel):
    id: int = None  # Optional for creation
    name: str
    email: str

    class Config:
        orm_mode = True

class PerformanceMetrics(BaseModel):
    impressions: int
    clicks: int
    conversions: int

class Campaign(BaseModel):
    id: int = None  # Optional for creation
    campaign_name: str
    description: str
    start_date: datetime
    budget: int
    performance_metrics: List[PerformanceMetrics]
    canal: List[Literal['internet', 'tv', 'radio']]
    client_id: int

    class Config:
        orm_mode = True
        


