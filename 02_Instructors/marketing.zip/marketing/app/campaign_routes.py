from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app import models
from app import schemas
from app.database import get_db

router = APIRouter()

# Clients CRUD Operations

@router.post("/clients/", response_model=schemas.Client, summary="Create a new client", description="Add a new client to the database with a unique name and email.")
async def create_client(client: schemas.Client, db: Session = Depends(get_db)):
    db_client = models.Client(name=client.name, email=client.email)
    db.add(db_client)
    db.commit()
    db.refresh(db_client)
    return db_client

@router.get("/clients/", response_model=List[schemas.Client], summary="Retrieve all clients", description="Get a list of all clients, with optional pagination.")
async def read_clients(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    clients = db.query(models.Client).offset(skip).limit(limit).all()
    return clients

@router.get("/clients/{client_id}", response_model=schemas.Client, summary="Retrieve a client by ID", description="Get details of a specific client by their ID.")
async def read_client(client_id: int, db: Session = Depends(get_db)):
    try:
        client = db.query(models.Client).filter(models.Client.id == client_id).one()
        return client
    except Exception:
        raise HTTPException(status_code=404, detail="Client not found")

@router.put("/clients/{client_id}", response_model=schemas.Client, summary="Update a client", description="Update the details of an existing client by their ID.")
async def update_client(client_id: int, client: schemas.Client, db: Session = Depends(get_db)):
    try:
        db_client = db.query(models.Client).filter(models.Client.id == client_id).one()
        db_client.name = client.name
        db_client.email = client.email
        db.commit()
        db.refresh(db_client)
        return db_client
    except Exception:
        raise HTTPException(status_code=404, detail="Client not found")

@router.delete("/clients/{client_id}", response_model=schemas.Client, summary="Delete a client", description="Remove a client from the database by their ID.")
async def delete_client(client_id: int, db: Session = Depends(get_db)):
    try:
        db_client = db.query(models.Client).filter(models.Client.id == client_id).one()
        db.delete(db_client)
        db.commit()
        return db_client
    except Exception:
        raise HTTPException(status_code=404, detail="Client not found")

# Campaigns CRUD Operations

@router.post("/campaigns/", response_model=schemas.Campaign, summary="Create a new campaign", description="Add a new campaign to the database with a title, description, and associated client ID.")
async def create_campaign(campaign: schemas.Campaign, db: Session = Depends(get_db)):
    db_campaign = models.Campaign(title=campaign.title, description=campaign.description, client_id=campaign.client_id)
    db.add(db_campaign)
    db.commit()
    db.refresh(db_campaign)
    return db_campaign

@router.get("/campaigns/", response_model=List[schemas.Campaign], summary="Retrieve all campaigns", description="Get a list of all campaigns, with optional pagination.")
async def read_campaigns(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    campaigns = db.query(models.Campaign).offset(skip).limit(limit).all()
    for campaign in campaigns:
        campaign.canal = campaign.canal.split(',')  # Convert back to list
    return campaigns

@router.get("/campaigns/{campaign_id}", response_model=schemas.Campaign, summary="Retrieve a campaign by ID", description="Get details of a specific campaign by its ID.")
async def read_campaign(campaign_id: int, db: Session = Depends(get_db)):
    try:
        campaign = db.query(models.Campaign).filter(models.Campaign.id == campaign_id).one()
        if campaign.canal:
            campaign.canal = campaign.canal.split(',')
        return campaign
    except Exception:
        raise HTTPException(status_code=404, detail="Campaign not found")

@router.put("/campaigns/{campaign_id}", response_model=schemas.Campaign, summary="Update a campaign", description="Update the details of an existing campaign by its ID.")
async def update_campaign(campaign_id: int, campaign: schemas.Campaign, db: Session = Depends(get_db)):
    try:
        db_campaign = db.query(models.Campaign).filter(models.Campaign.id == campaign_id).one()
        db_campaign.title = campaign.title
        db_campaign.description = campaign.description
        db_campaign.client_id = campaign.client_id
        db.commit()
        db.refresh(db_campaign)
        return db_campaign
    except Exception:
        raise HTTPException(status_code=404, detail="Campaign not found")

@router.delete("/campaigns/{campaign_id}", response_model=schemas.Campaign, summary="Delete a campaign", description="Remove a campaign from the database by its ID.")
async def delete_campaign(campaign_id: int, db: Session = Depends(get_db)):
    try:
        db_campaign = db.query(models.Campaign).filter(models.Campaign.id == campaign_id).one()
        db.delete(db_campaign)
        db.commit()
        return db_campaign
    except Exception:
        raise HTTPException(status_code=404, detail="Campaign not found")
